# Manuscrito

Coloca aquí el manuscrito principal (Word) y/o los capítulos en Markdown.

Recomendación:
- `Manuscrito_Principal.docx`
- `capitulos/01-introduccion.md`, etc.

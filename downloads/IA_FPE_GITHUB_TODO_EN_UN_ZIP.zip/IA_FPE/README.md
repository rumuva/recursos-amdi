# IA_FPE — Arquitectura Estratégica de la IA para Docentes de FPE

**Autor:** Rubén Muñoz Valadés

Este repositorio contiene el material del libro y recursos asociados para integrar la IA en **Formación Profesional para el Empleo (FPE)** sin perder el control pedagógico.

## Qué encontrarás aquí

- 📘 **PDF (KDP-ready)**: versión maquetada 6x9 lista para revisión y publicación.
- 📘 **PDF de lectura**: versión completa para revisión (si está incluida).
- 🧩 **Extras**: plantillas, checklists y recursos (en preparación).
- 🌐 **Web (GitHub Pages)**: una landing simple en `/docs`.

## Descargas rápidas

- PDF maquetado (KDP): `pdf/Arquitectura_Estrategica_IA_Docentes_FPE_VERSION_FINAL_KDP.pdf`
- (Opcional) PDF completo: `pdf/Arquitectura_Estrategica_IA_Docentes_FPE_LIBRO_COMPLETO.pdf`

## Estructura del repositorio

```
IA_FPE/
  manuscrito/        # manuscrito y/o capítulos (Word/Markdown)
  pdf/               # PDFs listos para lectura / KDP
  extras/            # plantillas, rúbricas, checklists (premium)
  assets/            # imágenes (logo, mockups)
  docs/              # GitHub Pages (landing)
```

## Publicación y monetización (ruta recomendada)
1. Publica en **Amazon KDP** (impresión bajo demanda).
2. Mantén este repo como **landing + recursos**.
3. Crea una **Release** con una muestra gratuita (15–25 páginas).
4. (Opcional) Ofrece extras premium (plantillas/rúbricas) como upsell.

## Cómo activar GitHub Pages
1. Ve a **Settings → Pages**
2. Source: **Deploy from a branch**
3. Branch: **main** / Folder: **/docs**
4. Guarda. Tu web quedará publicada en minutos.

## Nota sobre el manuscrito Word
Si tu manuscrito original (`Inteligencia_Artificial_FPE_Borrador_v8.docx`) está en tu equipo o ya en el repo, colócalo en `manuscrito/` para mantenerlo organizado.

---
© 2026 Rubén Muñoz Valadés. Todos los derechos reservados.

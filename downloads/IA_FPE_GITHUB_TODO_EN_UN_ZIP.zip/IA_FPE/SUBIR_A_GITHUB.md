# Subida rápida a GitHub (paso a paso)

1) Descarga este ZIP y descomprímelo.
2) Copia el contenido dentro de tu repo `IA_FPE` (o reemplaza la estructura).
3) Haz commit y push.

## Activar GitHub Pages
- Settings → Pages → Deploy from a branch → main → /docs

## Recomendación de Releases
- v0.9 Preview: sube una muestra en PDF (15–25 páginas)
- v1.0: PDF final + extras

